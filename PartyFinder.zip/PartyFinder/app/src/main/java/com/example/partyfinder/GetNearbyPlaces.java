package com.example.partyfinder;

import android.os.AsyncTask;

public class GetNearbyPlaces extends AsyncTask<Object,String,String> {
    @Override
    protected String doInBackground(Object... objects) {
        return null;
    }

    @Override
    protected void onPostExecute(String s) {
        super.onPostExecute(s);
    }
}
